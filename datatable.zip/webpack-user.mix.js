const mix = require('laravel-mix');

mix.js('resources/js/user.js', 'public/panel/user/js');