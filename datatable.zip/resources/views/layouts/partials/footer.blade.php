<footer class="main-footer text-center">
    <strong>CopyRight &copy; 2020 <a href="http://adminlte.io/">adminlte</a>.</strong>
</footer>