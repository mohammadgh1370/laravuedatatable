<template>
    <div class="alert alert-primary" role="alert">
        <font-awesome-icon :icon="['fas', 'info-circle']" />&nbsp;
        <slot></slot>
    </div>
</template>
