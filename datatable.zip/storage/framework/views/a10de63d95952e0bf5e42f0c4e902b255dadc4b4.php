

<?php $__env->startSection('page-title', 'ادمین ها'); ?>
<?php $__env->startSection('path', 'ادمین'); ?>
<?php $__env->startSection('location', 'همه'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_index')): ?>
                <data-table <?php echo vue_props($props); ?>></data-table>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\datatable\resources\views/admin/admin/index.blade.php ENDPATH**/ ?>