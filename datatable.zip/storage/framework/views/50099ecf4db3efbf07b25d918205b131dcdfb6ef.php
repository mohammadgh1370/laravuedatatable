<aside class="main-sidebar elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <img src="<?php echo e(asset('images/AdminLTELogo.png')); ?>" alt="AdminLTE Logo"
             class="brand-image img-circle elevation-3"
             style="opacity: .9;background-color:white;">
        <span class="brand-text font-weight-light">پنل مدیریت</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <div>
            <!-- Sidebar user panel (optional) -->
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                <div class="image">
                    <img src="<?php echo e(auth()->guard('admin')->user()->avatar); ?>" class="img-circle elevation-2"
                         alt="User Image">
                </div>
                <div class="info">
                    <a href="#" class="d-block"><?php echo e(auth()->guard('admin')->user()->full_name); ?></a>
                </div>
            </div>

            <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                    data-accordion="false">

                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.dashboard')); ?>"
                           class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'dashboard')): ?> active <?php endif; ?>">
                            <i class="nav-icon fas fa-tachometer-alt faa-float <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.dashboard')): ?> animated <?php endif; ?>"></i>
                            <p>
                                داشبورد
                            </p>
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin_index','user_index'],'admin')): ?>
                        <li class="nav-item has-treeview <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.*','user.*')): ?> menu-open <?php endif; ?>">
                            <a href="#"
                               class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.*','user.*')): ?> active <?php endif; ?>">
                                <i class="nav-icon fas fa-users faa-tada <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.*','user.*')): ?> animated <?php endif; ?>"></i>
                                <p>
                                    کاربران
                                    <i class="right fa fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_index','admin')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('admin.admin.index')); ?>"
                                           class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.*')): ?> active <?php endif; ?>">
                                            <i class="fas fa-user-secret nav-icon faa-horizontal <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'admin.*')): ?> animated <?php endif; ?>"></i>
                                            <p>
                                                ادمین ها
                                            </p>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_index','admin')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('admin.user.index')); ?>"
                                           class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'user.*')): ?> active <?php endif; ?>">
                                            <i class="fas fa-user nav-icon faa-horizontal <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'user.*')): ?> animated <?php endif; ?>"></i>
                                            <p>
                                                کاربران
                                            </p>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if(auth('admin')->check() && auth('admin')->user()->hasRole('admin')): ?>
                    <li class="nav-item has-treeview <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'role.*','permission.*')): ?> menu-open <?php endif; ?>">
                        <a href="#" class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'role.*','permission.*')): ?> active <?php endif; ?>">
                            <i class="nav-icon fas fa-ban faa-tada <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'role.*','permission.*')): ?> animated <?php endif; ?>"></i>
                            <p>
                                سطح دسترسی
                                <i class="right fa fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item has-treeview <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'role.*')): ?> menu-open <?php endif; ?>">
                                <a href="<?php echo e(route('admin.role.index')); ?>"
                                   class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'role.*')): ?> active <?php endif; ?>">
                                    <i class="fas fa-key nav-icon faa-horizontal <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'role.*')): ?> animated <?php endif; ?>"></i>
                                    <p>
                                        نقش ها
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item has-treeview <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'permission.*')): ?> menu-open <?php endif; ?>">
                                <a href="<?php echo e(route('admin.permission.index')); ?>"
                                   class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'permission.*')): ?> active <?php endif; ?>">
                                    <i class="fas fa-unlock-alt nav-icon faa-horizontal <?php if (\Illuminate\Support\Facades\Blade::check('routeis', 'permission.*')): ?> animated <?php endif; ?>"></i>
                                    <p>
                                        مجوزها
                                    </p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>

                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH F:\xampp\htdocs\datatable\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>