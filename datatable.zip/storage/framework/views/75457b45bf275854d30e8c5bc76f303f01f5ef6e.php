<flash :error="<?php echo e(json_encode(['code' => -1, 'message' => $errors->all()])); ?>"
       :success="<?php echo e(json_encode(Session::get('flash'))); ?>"></flash>
<?php /**PATH E:\datatable\resources\views/admin/partials/flash.blade.php ENDPATH**/ ?>