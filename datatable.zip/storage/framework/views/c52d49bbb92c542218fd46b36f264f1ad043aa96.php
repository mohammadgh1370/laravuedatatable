<?php $__env->startSection('page-title', 'مجوز ها'); ?>
<?php $__env->startSection('path', 'مجوز'); ?>
<?php $__env->startSection('location', 'همه'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_create')): ?>
                <a href="<?php echo e(route('admin.permission.create')); ?>"
                   class="btn btn-success btn-sm float-left mb-4">
                    ایجاد مجوز
                    <i class="fa fa-plus"></i>
                </a>
            <?php endif; ?>
        </div>
        <div class="col-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_index')): ?>
                <data-table <?php echo vue_props($props); ?>></data-table>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\datatable\resources\views/admin/permission/index.blade.php ENDPATH**/ ?>