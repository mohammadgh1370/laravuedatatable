<!DOCTYPE html>
<html lang="<?php echo e(App::getLocale()); ?>" dir="<?php echo e(App::isLocale('en') ? 'ltr' : 'rtl'); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="guard" content="<?php echo e(\Auth::getDefaultDriver() != 'web' ?\Auth::getDefaultDriver() : 'user'); ?>">
    <title><?php echo $__env->yieldContent('page-title'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('panel/app/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('panel/app/css/panel.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body class="hold-transition <?php echo $__env->yieldContent('class'); ?> sans">

<div id="<?php echo e(\Auth::getDefaultDriver() != 'web' ?\Auth::getDefaultDriver() : 'user'); ?>">

    <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('main'); ?>

</div>
<script src="<?php echo e(asset('panel/app/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('panel/app/js/panel.js')); ?>" defer></script>
<?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /**PATH F:\xampp\htdocs\datatable\resources\views/layouts/app.blade.php ENDPATH**/ ?>