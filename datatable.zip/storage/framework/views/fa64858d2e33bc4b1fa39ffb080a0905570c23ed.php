<?php $__env->startSection('page-title', 'نقش ها'); ?>
<?php $__env->startSection('path', 'نقش'); ?>
<?php $__env->startSection('location', 'ایجاد نقش'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_create')): ?>
                <form action="<?php echo e(route('admin.role.store')); ?>" class="row" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">نام نقش</label>
                            <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" type="text"
                                   value="<?php echo e(old('name')); ?>"
                                   placeholder="نام نقش را وارد کنید، برای مثال: writer">
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="label">برچسب نقش</label>
                            <input class="form-control <?php $__errorArgs = ['label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="label" type="text"
                                   value="<?php echo e(old('label')); ?>"
                                   placeholder="برچسب نقش را وارد کنید، برای مثال: نویسنده">
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="guard_name">نوع کاربر</label>
                            <select class="form-control <?php $__errorArgs = ['guard_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="guard_name">
                                <option>نوع کاربر را انتخاب کنید</option>
                                <?php $__currentLoopData = $guards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($guard); ?>"><?php echo e($guard); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="guard_name">مجوزها</label>
                            <select-search :options="<?php echo e(json_encode($permissions)); ?>"
                                           name="permission_id"
                                           key-option="label"
                                           key-data="id"
                                           classes="<?php $__errorArgs = ['permission_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           placeholder="مجوز را انتخاب کنید"
                                           :multiple="true"></select-search>
                        </div>
                    </div>

                    <div class="col-md-12 mt-5">
                        <button class="btn btn-block btn-primary">تایید</button>
                    </div>

                </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\datatable\resources\views/admin/role/create.blade.php ENDPATH**/ ?>