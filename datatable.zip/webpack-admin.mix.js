const mix = require('laravel-mix');

mix.js('resources/js/admin.js', 'public/panel/admin/js');